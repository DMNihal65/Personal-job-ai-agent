import { 
  Title, 
  Text, 
  Button, 
  Card, 
  Group, 
  Stack, 
  Badge, 
  Divider, 
  Progress, 
  Container, 
  SimpleGrid, 
  List,
  Accordion,
  Box,
  Paper,
  Anchor,
  ThemeIcon,
  RingProgress,
  ActionIcon
} from '@mantine/core';
import { 
  IconCheck, 
  IconX, 
  IconArrowRight, 
  IconBriefcase, 
  IconSchool, 
  IconTrophy, 
  IconBulb, 
  IconChartBar,
  IconExternalLink,
  IconStar,
  IconTools,
  IconWorld
} from '@tabler/icons-react';
import { useJobContext } from '../context/JobContext';

const ResumeAnalysis = () => {
  const { resumeAnalysis, setStep } = useJobContext();

  if (!resumeAnalysis) {
    return (
      <Container size="sm" py="xl" className="text-center">
        <Stack spacing="md">
          <Title order={3}>No resume analysis available</Title>
          <Text c="dimmed">Please upload your resume first</Text>
          <Button onClick={() => setStep(1)}>
            Go to Upload Resume
          </Button>
        </Stack>
      </Container>
    );
  }

  const {
    personal_info = {},
    skills = {},
    experience = [],
    education = [],
    professional_snapshot = '',
    technical_expertise_summary = '',
    soft_skills_summary = '',
    unique_selling_points = [],
    ats_score = {},
    improvement_suggestions = [],
    potential_roles = []
  } = resumeAnalysis;

  // Format skills for display
  const formatSkills = (skillArray = []) => {
    return skillArray?.map((skill, index) => (
      <Badge key={index} color="blue" variant="light" size="md" className="mr-2 mb-2">
        {skill}
      </Badge>
    ));
  };

  // Get color for ATS score
  const getScoreColor = (score) => {
    const numScore = parseInt(score || 0);
    if (numScore >= 8) return 'green';
    if (numScore >= 6) return 'blue';
    if (numScore >= 4) return 'yellow';
    return 'red';
  };

  return (
    <Container size="lg" py="xl">
      <Stack spacing="xl">
        <Box className="text-center">
          <Title order={1} className="text-blue-700 mb-2">Resume Analysis</Title>
          <Text size="lg" c="dimmed" className="max-w-2xl mx-auto">
            Here's what we found in your resume
          </Text>
        </Box>

        {/* Personal Information */}
        <Card withBorder shadow="sm" radius="md" className="bg-blue-50/30">
          <Group position="apart" align="flex-start">
            <div>
              <Title order={3} className="mb-1 text-blue-800">{personal_info.name}</Title>
              <Text c="dimmed" className="mb-1">{personal_info.email} • {personal_info.phone}</Text>
              <Text c="dimmed">{personal_info.location}</Text>
            </div>
            <Group>
              {personal_info.linkedin && (
                <Button 
                  component="a" 
                  href={personal_info.linkedin} 
                  target="_blank"
                  variant="light"
                  size="xs"
                  rightSection={<IconExternalLink size={14} />}
                >
                  LinkedIn
                </Button>
              )}
              {personal_info.github && (
                <Button 
                  component="a" 
                  href={personal_info.github} 
                  target="_blank"
                  variant="light"
                  size="xs"
                  rightSection={<IconExternalLink size={14} />}
                >
                  GitHub
                </Button>
              )}
              {personal_info.portfolio && (
                <Button 
                  component="a" 
                  href={personal_info.portfolio} 
                  target="_blank"
                  variant="light"
                  size="xs"
                  rightSection={<IconExternalLink size={14} />}
                >
                  Portfolio
                </Button>
              )}
            </Group>
          </Group>
        </Card>

        {/* Professional Snapshot */}
        {professional_snapshot && (
          <Card withBorder shadow="sm" radius="md">
            <Title order={4} className="mb-3 text-blue-700">Professional Snapshot</Title>
            <Text className="leading-relaxed">{professional_snapshot}</Text>
          </Card>
        )}

        {/* ATS Score */}
        <Card withBorder shadow="sm" radius="md">
          <Title order={4} className="mb-4 text-blue-700">ATS Optimization Score</Title>
          <SimpleGrid cols={{ base: 1, sm: 4 }} spacing="md">
            <Box className="text-center">
              <RingProgress
                size={120}
                thickness={12}
                roundCaps
                sections={[{ value: parseInt(ats_score.overall || 0) * 10, color: getScoreColor(ats_score.overall) }]}
                label={
                  <Box className="text-center">
                    <Text fw={700} ta="center" size="xl">
                      {ats_score.overall || 0}
                    </Text>
                    <Text size="xs" c="dimmed">out of 10</Text>
                  </Box>
                }
              />
              <Text mt="sm" fw={500}>Overall</Text>
            </Box>
            <Box className="text-center">
              <RingProgress
                size={120}
                thickness={12}
                roundCaps
                sections={[{ value: parseInt(ats_score.formatting || 0) * 10, color: getScoreColor(ats_score.formatting) }]}
                label={
                  <Box className="text-center">
                    <Text fw={700} ta="center" size="xl">
                      {ats_score.formatting || 0}
                    </Text>
                    <Text size="xs" c="dimmed">out of 10</Text>
                  </Box>
                }
              />
              <Text mt="sm" fw={500}>Formatting</Text>
            </Box>
            <Box className="text-center">
              <RingProgress
                size={120}
                thickness={12}
                roundCaps
                sections={[{ value: parseInt(ats_score.keyword_optimization || 0) * 10, color: getScoreColor(ats_score.keyword_optimization) }]}
                label={
                  <Box className="text-center">
                    <Text fw={700} ta="center" size="xl">
                      {ats_score.keyword_optimization || 0}
                    </Text>
                    <Text size="xs" c="dimmed">out of 10</Text>
                  </Box>
                }
              />
              <Text mt="sm" fw={500}>Keywords</Text>
            </Box>
            <Box className="text-center">
              <RingProgress
                size={120}
                thickness={12}
                roundCaps
                sections={[{ value: parseInt(ats_score.content_quality || 0) * 10, color: getScoreColor(ats_score.content_quality) }]}
                label={
                  <Box className="text-center">
                    <Text fw={700} ta="center" size="xl">
                      {ats_score.content_quality || 0}
                    </Text>
                    <Text size="xs" c="dimmed">out of 10</Text>
                  </Box>
                }
              />
              <Text mt="sm" fw={500}>Content</Text>
            </Box>
          </SimpleGrid>
        </Card>

        {/* Skills */}
        <Card withBorder shadow="sm" radius="md">
          <Title order={4} className="mb-3 text-blue-700">Skills</Title>
          
          {technical_expertise_summary && (
            <Paper withBorder p="md" radius="md" mb="md" className="bg-blue-50/30">
              <Text fw={500} className="text-blue-800 mb-2">Technical Expertise:</Text>
              <Text className="leading-relaxed">{technical_expertise_summary}</Text>
            </Paper>
          )}
          
          {soft_skills_summary && (
            <Paper withBorder p="md" radius="md" mb="md" className="bg-green-50/30">
              <Text fw={500} className="text-green-800 mb-2">Soft Skills:</Text>
              <Text className="leading-relaxed">{soft_skills_summary}</Text>
            </Paper>
          )}
          
          <Accordion variant="separated" radius="md" mt="md">
            <Accordion.Item value="technical">
              <Accordion.Control>
                <Group>
                  <ThemeIcon color="blue" size={24} radius="xl">
                    <IconBriefcase size={16} />
                  </ThemeIcon>
                  <Text fw={500}>Technical Skills</Text>
                </Group>
              </Accordion.Control>
              <Accordion.Panel>
                <Group spacing={8}>
                  {formatSkills(skills.technical)}
                </Group>
              </Accordion.Panel>
            </Accordion.Item>
            <Accordion.Item value="soft">
              <Accordion.Control>
                <Group>
                  <ThemeIcon color="green" size={24} radius="xl">
                    <IconBulb size={16} />
                  </ThemeIcon>
                  <Text fw={500}>Soft Skills</Text>
                </Group>
              </Accordion.Control>
              <Accordion.Panel>
                <Group spacing={8}>
                  {formatSkills(skills.soft)}
                </Group>
              </Accordion.Panel>
            </Accordion.Item>
            <Accordion.Item value="tools">
              <Accordion.Control>
                <Group>
                  <ThemeIcon color="indigo" size={24} radius="xl">
                    <IconTools size={16} />
                  </ThemeIcon>
                  <Text fw={500}>Tools & Technologies</Text>
                </Group>
              </Accordion.Control>
              <Accordion.Panel>
                <Group spacing={8}>
                  {formatSkills([...skills.tools || [], ...skills.frameworks || []])}
                </Group>
              </Accordion.Panel>
            </Accordion.Item>
            <Accordion.Item value="languages">
              <Accordion.Control>
                <Group>
                  <ThemeIcon color="cyan" size={24} radius="xl">
                    <IconWorld size={16} />
                  </ThemeIcon>
                  <Text fw={500}>Languages</Text>
                </Group>
              </Accordion.Control>
              <Accordion.Panel>
                <Group spacing={8}>
                  {formatSkills(skills.languages)}
                </Group>
              </Accordion.Panel>
            </Accordion.Item>
            <Accordion.Item value="domain">
              <Accordion.Control>
                <Group>
                  <ThemeIcon color="violet" size={24} radius="xl">
                    <IconBriefcase size={16} />
                  </ThemeIcon>
                  <Text fw={500}>Domain Knowledge</Text>
                </Group>
              </Accordion.Control>
              <Accordion.Panel>
                <Group spacing={8}>
                  {formatSkills(skills.domain_knowledge)}
                </Group>
              </Accordion.Panel>
            </Accordion.Item>
          </Accordion>
        </Card>

        {/* Experience */}
        <Card withBorder shadow="sm" radius="md">
          <Title order={4} className="mb-3 text-blue-700">
            <Group spacing="xs">
              <IconBriefcase size={20} />
              <span>Experience</span>
            </Group>
          </Title>
          <Stack spacing="md">
            {experience.slice(0, 3).map((item, index) => (
              <Paper key={index} p="md" withBorder className={index % 2 === 0 ? "bg-blue-50/30" : ""}>
                <Group position="apart" mb="xs">
                  <Text fw={700} className="text-blue-800">{item.title}</Text>
                  <Badge color="blue" variant="light">{item.duration}</Badge>
                </Group>
                <Group position="apart" mb="md">
                  <Text fw={500}>{item.company}</Text>
                  <Text c="dimmed">{item.location}</Text>
                </Group>
                {item.responsibilities && item.responsibilities.length > 0 && (
                  <Box mt="sm">
                    <Text fw={500} className="text-blue-700">Responsibilities:</Text>
                    <List spacing="xs" size="sm" mt="xs">
                      {item.responsibilities.map((resp, idx) => (
                        <List.Item key={idx}>{resp}</List.Item>
                      ))}
                    </List>
                  </Box>
                )}
                {item.achievements && item.achievements.length > 0 && (
                  <Box mt="sm">
                    <Text fw={500} className="text-green-700">Achievements:</Text>
                    <List 
                      spacing="xs" 
                      size="sm" 
                      mt="xs"
                      icon={
                        <ThemeIcon color="green" size={20} radius="xl">
                          <IconStar size={12} />
                        </ThemeIcon>
                      }
                    >
                      {item.achievements.map((achievement, idx) => (
                        <List.Item key={idx}>{achievement}</List.Item>
                      ))}
                    </List>
                  </Box>
                )}
                {item.impact && (
                  <Box mt="sm">
                    <Text fw={500} className="text-indigo-700">Impact:</Text>
                    <Text className="leading-relaxed">{item.impact}</Text>
                  </Box>
                )}
              </Paper>
            ))}
            {experience.length > 3 && (
              <Text ta="center" c="dimmed">+ {experience.length - 3} more experiences</Text>
            )}
          </Stack>
        </Card>

        {/* Education */}
        <Card withBorder shadow="sm" radius="md">
          <Title order={4} className="mb-3 text-blue-700">
            <Group spacing="xs">
              <IconSchool size={20} />
              <span>Education</span>
            </Group>
          </Title>
          <Stack spacing="md">
            {education.map((item, index) => (
              <Paper key={index} p="md" withBorder className={index % 2 === 0 ? "bg-blue-50/30" : ""}>
                <Group position="apart" mb="xs">
                  <Text fw={700} className="text-blue-800">{item.degree}</Text>
                  <Badge color="blue" variant="light">{item.graduation_date}</Badge>
                </Group>
                <Group position="apart" mb="md">
                  <Text fw={500}>{item.institution}</Text>
                  <Text c="dimmed">{item.location}</Text>
                </Group>
                {item.gpa && (
                  <Text mt="xs"><strong>GPA:</strong> {item.gpa}</Text>
                )}
                {item.honors && item.honors.length > 0 && (
                  <Text mt="xs"><strong>Honors:</strong> {item.honors.join(', ')}</Text>
                )}
              </Paper>
            ))}
          </Stack>
        </Card>

        {/* Unique Selling Points */}
        {unique_selling_points && unique_selling_points.length > 0 && (
          <Card withBorder shadow="sm" radius="md" className="bg-green-50/30">
            <Title order={4} className="mb-3 text-green-800">Your Unique Selling Points</Title>
            <List
              spacing="sm"
              icon={
                <ThemeIcon color="green" size={24} radius="xl">
                  <IconCheck size={16} />
                </ThemeIcon>
              }
            >
              {unique_selling_points.map((item, index) => (
                <List.Item key={index}>{item}</List.Item>
              ))}
            </List>
          </Card>
        )}

        {/* Improvement Suggestions */}
        {improvement_suggestions && improvement_suggestions.length > 0 && (
          <Card withBorder shadow="sm" radius="md" className="bg-amber-50/30">
            <Title order={4} className="mb-3 text-amber-800">Improvement Suggestions</Title>
            <List spacing="md">
              {improvement_suggestions.map((item, index) => (
                <List.Item
                  key={index}
                  icon={
                    <ThemeIcon color="amber" size={24} radius="xl">
                      <IconArrowRight size={16} />
                    </ThemeIcon>
                  }
                >
                  <Text fw={500}>{item.section}: </Text>
                  {item.suggestion}
                  {item.reason && (
                    <Text c="dimmed" mt="xs" fz="sm" fs="italic">
                      Why: {item.reason}
                    </Text>
                  )}
                </List.Item>
              ))}
            </List>
          </Card>
        )}

        {/* Potential Roles */}
        {potential_roles && potential_roles.length > 0 && (
          <Card withBorder shadow="sm" radius="md" className="bg-indigo-50/30">
            <Title order={4} className="mb-3 text-indigo-800">Potential Roles You Could Apply For</Title>
            <Group spacing={8}>
              {potential_roles.map((role, index) => (
                <Badge key={index} color="indigo" size="lg" variant="filled" radius="sm">
                  {role}
                </Badge>
              ))}
            </Group>
          </Card>
        )}

        <Box className="text-center" mt="md">
          <Button 
            size="lg"
            rightSection={<IconArrowRight size={16} />}
            onClick={() => setStep(3)}
            color="blue"
          >
            Continue to Job URL
          </Button>
        </Box>
      </Stack>
    </Container>
  );
};

export default ResumeAnalysis; 