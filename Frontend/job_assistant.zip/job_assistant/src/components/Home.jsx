import { useState } from 'react';
import { 
  Title, 
  Text, 
  Button, 
  Card, 
  Group, 
  SimpleGrid, 
  Stack, 
  List, 
  ThemeIcon, 
  rem, 
  Container,
  Stepper,
  Divider,
  Box,
  Paper
} from '@mantine/core';
import { Dropzone } from '@mantine/dropzone';
import { notifications } from '@mantine/notifications';
import { 
  IconFileText, 
  IconBriefcase, 
  IconChartPie, 
  IconMessageCircle, 
  IconCheck, 
  IconUpload, 
  IconArrowRight,
  IconCircleCheck,
  IconCircleDashed
} from '@tabler/icons-react';
import { useJobContext } from '../context/JobContext';

const Home = () => {
  const { 
    step, 
    setStep, 
    handleResumeUpload, 
    resumeFile,
    resumeAnalysis,
    jobAnalysis,
    skillMatch
  } = useJobContext();
  
  const [dragActive, setDragActive] = useState(false);

  // Handle file upload
  const handleDrop = (files) => {
    const file = files[0];
    if (file.type !== 'application/pdf') {
      notifications.show({
        title: 'Invalid file type',
        message: 'Please upload a PDF file',
        color: 'red',
      });
      return;
    }
    
    handleResumeUpload(file);
    notifications.show({
      title: 'Resume uploaded',
      message: 'Your resume is being processed',
      color: 'blue',
    });
  };

  // Define the steps for the application
  const steps = [
    {
      title: 'Upload Resume',
      description: 'Upload your resume in PDF format',
      icon: <IconFileText size={18} stroke={1.5} />,
      status: resumeAnalysis ? 'completed' : step === 1 ? 'current' : 'waiting',
    },
    {
      title: 'Enter Job URL',
      description: 'Provide a job posting URL',
      icon: <IconBriefcase size={18} stroke={1.5} />,
      status: jobAnalysis ? 'completed' : step === 2 ? 'current' : 'waiting',
    },
    {
      title: 'Skill Match',
      description: 'View skill match analysis',
      icon: <IconChartPie size={18} stroke={1.5} />,
      status: skillMatch ? 'completed' : step === 3 ? 'current' : 'waiting',
    },
    {
      title: 'Interview Q&A',
      description: 'Get answers to interview questions',
      icon: <IconMessageCircle size={18} stroke={1.5} />,
      status: step === 4 ? 'current' : 'waiting',
    },
  ];

  const features = [
    {
      icon: <IconFileText size={24} stroke={1.5} className="text-blue-500" />,
      title: "Resume Analysis",
      description: "Get detailed insights about your resume including skills, experience, and ATS optimization score."
    },
    {
      icon: <IconBriefcase size={24} stroke={1.5} className="text-blue-500" />,
      title: "Job Analysis",
      description: "Understand job requirements, key skills needed, and what employers are looking for."
    },
    {
      icon: <IconChartPie size={24} stroke={1.5} className="text-blue-500" />,
      title: "Skill Matching",
      description: "See how well your skills match the job requirements and get suggestions for improvement."
    },
    {
      icon: <IconMessageCircle size={24} stroke={1.5} className="text-blue-500" />,
      title: "Interview Preparation",
      description: "Get personalized answers to common interview questions based on your experience."
    }
  ];

  return (
    <Container size="lg" py="xl">
      <Stack spacing="xl">
        <Box className="text-center">
          <Title order={1} className="text-blue-700 mb-2">Job Application Assistant</Title>
          <Text size="lg" c="dimmed" className="max-w-2xl mx-auto">
            Your AI-powered tool to help you prepare for job applications and interviews. 
            Upload your resume, analyze job descriptions, and get personalized insights.
          </Text>
        </Box>

        <Paper withBorder p="md" radius="md" className="bg-blue-50/30">
          <Stepper active={step - 1} breakpoint="sm">
            {steps.map((item, index) => (
              <Stepper.Step
                key={index}
                label={item.title}
                description={item.description}
                icon={item.icon}
                completedIcon={<IconCheck size={18} />}
                color="blue"
              />
            ))}
          </Stepper>
        </Paper>

        <SimpleGrid cols={{ base: 1, sm: 2 }} spacing="md">
          {features.map((feature, index) => (
            <Card key={index} withBorder shadow="sm" radius="md" className="hover:shadow-md transition-shadow duration-300">
              <Group>
                <ThemeIcon size="lg" radius="md" variant="light" color="blue">
                  {feature.icon}
                </ThemeIcon>
                <Box>
                  <Text fw={500}>{feature.title}</Text>
                  <Text size="sm" c="dimmed">{feature.description}</Text>
                </Box>
              </Group>
            </Card>
          ))}
        </SimpleGrid>

        <Card withBorder shadow="sm" radius="md" className="border-blue-100 bg-blue-50/30">
          <Stack>
            <Group>
              <ThemeIcon size="lg" radius="md" color="blue">
                <IconUpload size={18} />
              </ThemeIcon>
              <Title order={4}>Let's Get Started</Title>
            </Group>
            
            <Text>
              First, upload your resume in PDF format. We'll analyze it to extract your skills, 
              experience, and qualifications.
            </Text>

            <Dropzone
              onDrop={handleDrop}
              maxSize={5 * 1024 * 1024}
              accept={['application/pdf']}
              className={`border-2 border-dashed p-6 rounded-lg text-center ${
                dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
              }`}
              onDragEnter={() => setDragActive(true)}
              onDragLeave={() => setDragActive(false)}
            >
              <Stack align="center" spacing="xs">
                <Dropzone.Accept>
                  <IconUpload
                    size={50}
                    stroke={1.5}
                    className="text-blue-500"
                  />
                </Dropzone.Accept>
                <Dropzone.Reject>
                  <IconUpload
                    size={50}
                    stroke={1.5}
                    className="text-red-500"
                  />
                </Dropzone.Reject>
                <Dropzone.Idle>
                  <IconUpload
                    size={50}
                    stroke={1.5}
                    className="text-gray-500"
                  />
                </Dropzone.Idle>

                <Text size="xl" fw={600} inline>
                  Click or drag your resume PDF to this area
                </Text>
                <Text size="sm" c="dimmed" inline mt={7}>
                  Your resume will be analyzed to extract skills, experience, and qualifications
                </Text>
              </Stack>
            </Dropzone>

            {resumeFile && (
              <Paper p="sm" withBorder radius="md" className="bg-green-50 border-green-100">
                <Group>
                  <IconCircleCheck size={18} className="text-green-500" />
                  <Text fw={500} className="text-green-700">
                    Resume uploaded: {resumeFile.name}
                  </Text>
                </Group>
              </Paper>
            )}
          </Stack>
        </Card>

        {resumeAnalysis && (
          <Box className="text-center">
            <Button 
              size="lg"
              rightSection={<IconArrowRight size={16} />}
              onClick={() => setStep(2)}
            >
              Continue to Job URL
            </Button>
          </Box>
        )}

        <Paper withBorder p="lg" radius="md" className="bg-gray-50">
          <Title order={5} mb="md">How It Works</Title>
          <List
            spacing="sm"
            size="sm"
            center
            icon={
              <ThemeIcon color="blue" size={24} radius="xl">
                <IconCircleDashed size={16} />
              </ThemeIcon>
            }
          >
            <List.Item>Upload your resume (PDF format)</List.Item>
            <List.Item>Enter a job posting URL you're interested in</List.Item>
            <List.Item>Get a detailed analysis of how your skills match the job requirements</List.Item>
            <List.Item>Receive personalized answers to common interview questions</List.Item>
            <List.Item>Use the insights to improve your resume and prepare for interviews</List.Item>
          </List>
        </Paper>
      </Stack>
    </Container>
  );
};

export default Home; 