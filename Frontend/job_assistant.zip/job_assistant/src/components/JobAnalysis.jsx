import { useState, useRef } from 'react';
import { 
  Title, 
  Text, 
  Button, 
  Card, 
  Group, 
  Stack, 
  TextInput, 
  Badge, 
  Container, 
  Paper, 
  Accordion, 
  Box, 
  Divider,
  List,
  ThemeIcon,
  Loader,
  Alert,
  Image,
  ActionIcon
} from '@mantine/core';
import { 
  IconArrowRight, 
  IconBriefcase, 
  IconBuilding, 
  IconWorld, 
  IconInfoCircle, 
  IconAlertCircle,
//   IconTools,
  IconBulb,
  IconCheck,
  IconSearch,
  IconExternalLink,
  IconTools
} from '@tabler/icons-react';
import { useJobContext } from '../context/JobContext';

const JobAnalysis = () => {
  const { 
    jobUrl, 
    jobAnalysis, 
    handleJobUrlSubmit, 
    setStep, 
    jobProcessing 
  } = useJobContext();
  
  const [localJobUrl, setLocalJobUrl] = useState(jobUrl || '');
  const [error, setError] = useState('');
  const [localJobProcessing, setLocalJobProcessing] = useState(false);
  const inputRef = useRef(null);

  const handleJobUrlChange = (e) => {
    const value = e.target.value;
    setLocalJobUrl(value);
    setError('');
  };

  const handlePaste = (e) => {
    const pastedText = e.clipboardData.getData('text');
    setLocalJobUrl(pastedText);
    setError('');
    e.preventDefault();
  };

  const handleAnalyzeJob = async () => {
    if (!localJobUrl) {
      setError('Please enter a job URL');
      return;
    }

    if (!localJobUrl.startsWith('http')) {
      setError('Please enter a valid URL starting with http:// or https://');
      return;
    }

    setLocalJobProcessing(true);
    setError('');
    
    try {
      await handleJobUrlSubmit(localJobUrl);
    } catch (err) {
      setError(err.message || 'Failed to analyze job. Please try again.');
    } finally {
      setLocalJobProcessing(false);
    }
  };

  return (
    <Container size="lg" py="xl">
      <Stack spacing="xl">
        <Box className="text-center">
          <Title order={1} className="text-blue-700 mb-2">Job Analysis</Title>
          <Text size="lg" c="dimmed" className="max-w-2xl mx-auto">
            Enter a job posting URL to analyze the requirements and match with your resume
          </Text>
        </Box>

        {!jobAnalysis ? (
          <Card withBorder shadow="sm" radius="md" p="lg" className="bg-blue-50/30">
            <Stack spacing="md">
              <Group align="flex-start" spacing="xl">
                <Box style={{ flex: 1 }}>
                  <input
                    type="text"
                    className="mantine-TextInput-input mantine-TextInput-defaultVariant mantine-1n7xw29"
                    placeholder="https://www.example.com/job-posting"
                    value={localJobUrl}
                    onChange={handleJobUrlChange}
                    onPaste={handlePaste}
                    disabled={localJobProcessing || jobProcessing}
                    style={{ 
                      width: '100%', 
                      padding: '10px 12px',
                      fontSize: '16px',
                      borderRadius: '4px',
                      border: '1px solid #ced4da',
                      marginTop: '8px',
                      marginBottom: '8px'
                    }}
                  />
                  
                  <Button 
                    onClick={handleAnalyzeJob} 
                    loading={localJobProcessing || jobProcessing}
                    disabled={!localJobUrl || localJobProcessing || jobProcessing}
                    size="md"
                    mt="md"
                    fullWidth
                  >
                    {localJobProcessing || jobProcessing ? 'Analyzing Job...' : 'Analyze Job'}
                  </Button>
                </Box>
                
                <Box className="hidden md:block" style={{ maxWidth: '40%' }}>
                  <Paper withBorder p="md" radius="md" className="bg-white">
                    <Text fw={500} mb="xs">Tips for Job Analysis:</Text>
                    <List size="sm" spacing="xs">
                      <List.Item>Use direct links to job postings</List.Item>
                      <List.Item>Make sure the URL is publicly accessible</List.Item>
                      <List.Item>LinkedIn, Indeed, and company career pages work best</List.Item>
                    </List>
                  </Paper>
                </Box>
              </Group>
              
              {(localJobProcessing || jobProcessing) && (
                <Box className="text-center" mt="md">
                  <Loader size="md" />
                  <Text mt="sm" c="dimmed">
                    Analyzing job description. This may take a minute...
                  </Text>
                </Box>
              )}
              
              {error && (
                <Alert 
                  icon={<IconAlertCircle size={16} />} 
                  title="Error" 
                  color="red" 
                  variant="filled"
                >
                  {error}
                </Alert>
              )}
            </Stack>
          </Card>
        ) : (
          <Stack spacing="xl">
            {/* Job and Company Information */}
            <Card withBorder shadow="sm" radius="md" className="bg-blue-50/30">
              <Group position="apart" mb="md">
                <Title order={3} className="text-blue-800">{jobAnalysis.job_title}</Title>
                <Badge size="lg" color="blue" variant="filled">{jobAnalysis.job_type}</Badge>
              </Group>
              
              <Group mb="md" spacing="lg">
                <Group spacing="xs">
                  <IconBuilding size={18} className="text-blue-600" />
                  <Text fw={500}>{jobAnalysis.company_name}</Text>
                </Group>
                
                {jobAnalysis.location && (
                  <Group spacing="xs">
                    <IconWorld size={18} className="text-blue-600" />
                    <Text>{jobAnalysis.location}</Text>
                  </Group>
                )}
                
                {jobAnalysis.salary_range && (
                  <Badge color="green" variant="light" size="lg">
                    {jobAnalysis.salary_range}
                  </Badge>
                )}
              </Group>
              
              {jobAnalysis.application_deadline && (
                <Text c="dimmed" mb="md">
                  <strong>Application Deadline:</strong> {jobAnalysis.application_deadline}
                </Text>
              )}
              
              <Button 
                variant="light" 
                component="a" 
                href={jobUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                mb="md"
                rightSection={<IconExternalLink size={16} />}
              >
                View Original Job Posting
              </Button>
            </Card>
            
            {/* Position Overview */}
            {jobAnalysis.position_overview && (
              <Card withBorder shadow="sm" radius="md">
                <Title order={4} mb="md" className="text-blue-700">
                  <Group spacing="xs">
                    <IconBriefcase size={20} />
                    <span>Position Overview</span>
                  </Group>
                </Title>
                <Text className="leading-relaxed">{jobAnalysis.position_overview}</Text>
              </Card>
            )}
            
            {/* Company Overview */}
            {jobAnalysis.company_overview && (
              <Card withBorder shadow="sm" radius="md">
                <Title order={4} mb="md" className="text-blue-700">
                  <Group spacing="xs">
                    <IconBuilding size={20} />
                    <span>Company Overview</span>
                  </Group>
                </Title>
                <Text className="leading-relaxed">{jobAnalysis.company_overview}</Text>
              </Card>
            )}
            
            {/* Role Importance */}
            {jobAnalysis.role_importance && (
              <Card withBorder shadow="sm" radius="md">
                <Title order={4} mb="md" className="text-blue-700">
                  <Group spacing="xs">
                    <IconInfoCircle size={20} />
                    <span>Role Importance</span>
                  </Group>
                </Title>
                <Text className="leading-relaxed">{jobAnalysis.role_importance}</Text>
              </Card>
            )}
            
            {/* Required Skills */}
            {jobAnalysis.required_skills && jobAnalysis.required_skills.length > 0 && (
              <Card withBorder shadow="sm" radius="md">
                <Title order={4} mb="md" className="text-blue-700">Required Skills</Title>
                
                <Accordion variant="separated" radius="md">
                  {jobAnalysis.required_skills.technical && jobAnalysis.required_skills.technical.length > 0 && (
                    <Accordion.Item value="technical">
                      <Accordion.Control icon={<IconTools size={20} className="text-blue-600" />}>
                        <Text fw={500}>Technical Skills</Text>
                      </Accordion.Control>
                      <Accordion.Panel>
                        <List
                          spacing="sm"
                          icon={
                            <ThemeIcon color="blue" size={24} radius="xl">
                              <IconCheck size={16} />
                            </ThemeIcon>
                          }
                        >
                          {jobAnalysis.required_skills.technical.map((skill, index) => (
                            <List.Item key={index}>{skill}</List.Item>
                          ))}
                        </List>
                      </Accordion.Panel>
                    </Accordion.Item>
                  )}
                  
                  {jobAnalysis.required_skills.soft && jobAnalysis.required_skills.soft.length > 0 && (
                    <Accordion.Item value="soft">
                      <Accordion.Control icon={<IconBulb size={20} className="text-green-600" />}>
                        <Text fw={500}>Soft Skills</Text>
                      </Accordion.Control>
                      <Accordion.Panel>
                        <List
                          spacing="sm"
                          icon={
                            <ThemeIcon color="green" size={24} radius="xl">
                              <IconCheck size={16} />
                            </ThemeIcon>
                          }
                        >
                          {jobAnalysis.required_skills.soft.map((skill, index) => (
                            <List.Item key={index}>{skill}</List.Item>
                          ))}
                        </List>
                      </Accordion.Panel>
                    </Accordion.Item>
                  )}
                  
                  {jobAnalysis.required_skills.tools && jobAnalysis.required_skills.tools.length > 0 && (
                    <Accordion.Item value="tools">
                      <Accordion.Control icon={<IconTools size={20} className="text-indigo-600" />}>
                        <Text fw={500}>Tools & Technologies</Text>
                      </Accordion.Control>
                      <Accordion.Panel>
                        <List
                          spacing="sm"
                          icon={
                            <ThemeIcon color="indigo" size={24} radius="xl">
                              <IconCheck size={16} />
                            </ThemeIcon>
                          }
                        >
                          {jobAnalysis.required_skills.tools.map((tool, index) => (
                            <List.Item key={index}>{tool}</List.Item>
                          ))}
                        </List>
                      </Accordion.Panel>
                    </Accordion.Item>
                  )}
                  
                  {jobAnalysis.required_skills.domain_knowledge && jobAnalysis.required_skills.domain_knowledge.length > 0 && (
                    <Accordion.Item value="domain">
                      <Accordion.Control icon={<IconBriefcase size={20} className="text-violet-600" />}>
                        <Text fw={500}>Domain Knowledge</Text>
                      </Accordion.Control>
                      <Accordion.Panel>
                        <List
                          spacing="sm"
                          icon={
                            <ThemeIcon color="violet" size={24} radius="xl">
                              <IconCheck size={16} />
                            </ThemeIcon>
                          }
                        >
                          {jobAnalysis.required_skills.domain_knowledge.map((knowledge, index) => (
                            <List.Item key={index}>{knowledge}</List.Item>
                          ))}
                        </List>
                      </Accordion.Panel>
                    </Accordion.Item>
                  )}
                </Accordion>
              </Card>
            )}
            
            {/* Top Keywords */}
            {jobAnalysis.top_keywords && jobAnalysis.top_keywords.length > 0 && (
              <Card withBorder shadow="sm" radius="md">
                <Title order={4} mb="md" className="text-blue-700">Top Keywords</Title>
                <Group spacing={8}>
                  {jobAnalysis.top_keywords.map((keyword, index) => (
                    <Badge key={index} color="blue" variant="filled" size="lg" radius="sm">
                      {keyword}
                    </Badge>
                  ))}
                </Group>
              </Card>
            )}
            
            {/* Application Advice */}
            {jobAnalysis.application_advice && (
              <Card withBorder shadow="sm" radius="md" className="bg-blue-50/30">
                <Title order={4} mb="md" className="text-blue-700">Application Advice</Title>
                <Text className="leading-relaxed">{jobAnalysis.application_advice}</Text>
              </Card>
            )}
            
            <Box className="text-center" mt="md">
              <Button 
                size="lg"
                rightSection={<IconArrowRight size={16} />}
                onClick={() => setStep(4)}
                color="blue"
              >
                Continue to Skill Matching
              </Button>
            </Box>
          </Stack>
        )}
      </Stack>
    </Container>
  );
};

export default JobAnalysis; 