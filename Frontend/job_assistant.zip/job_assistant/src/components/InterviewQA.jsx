import { useState, useEffect } from 'react';
import { 
  Title, 
  Text, 
  Button, 
  Card, 
  Group, 
  Stack, 
  TextInput, 
  Container, 
  Paper, 
  Box, 
  Textarea,
  Select,
  Loader,
  Alert,
  Accordion,
  List,
  ThemeIcon,
  Divider
} from '@mantine/core';
import { 
  IconArrowRight, 
  IconBulb, 
  IconMessageCircle, 
  IconAlertCircle, 
  IconSearch,
  IconCheck,
  IconArrowLeft
} from '@tabler/icons-react';
import { useJobContext } from '../context/JobContext';

const InterviewQA = () => {
  const { 
    resumeAnalysis, 
    jobAnalysis, 
    skillMatch, 
    suggestedQuestions, 
    setSuggestedQuestions, 
    answeredQuestions, 
    setAnsweredQuestions, 
    setStep 
  } = useJobContext();
  
  const [question, setQuestion] = useState('');
  const [selectedQuestion, setSelectedQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  useEffect(() => {
    const fetchSuggestedQuestions = async () => {
      if (resumeAnalysis && jobAnalysis && !suggestedQuestions.length && !loadingSuggestions) {
        setLoadingSuggestions(true);
        try {
          // This would be replaced with an actual API call in a real application
          const response = await fetch('/api/suggested-questions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              resume: resumeAnalysis,
              job: jobAnalysis,
              skillMatch: skillMatch
            }),
          });
          
          if (!response.ok) {
            throw new Error('Failed to fetch suggested questions');
          }
          
          const data = await response.json();
          setSuggestedQuestions(data.questions || []);
        } catch (err) {
          setError('Failed to load suggested questions. Please try again.');
          console.error(err);
        } finally {
          setLoadingSuggestions(false);
        }
      }
    };
    
    fetchSuggestedQuestions();
  }, [resumeAnalysis, jobAnalysis, skillMatch, suggestedQuestions, setSuggestedQuestions, loadingSuggestions]);

  const handleQuestionChange = (e) => {
    setQuestion(e.target.value);
    setSelectedQuestion('');
    setError('');
  };

  const handleSelectedQuestionChange = (value) => {
    setSelectedQuestion(value);
    setQuestion(value);
    setError('');
  };

  const handleAskQuestion = async () => {
    if (!question.trim()) {
      setError('Please enter a question or select one from the suggestions');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // This would be replaced with an actual API call in a real application
      const response = await fetch('/api/answer-question', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: question,
          resume: resumeAnalysis,
          job: jobAnalysis,
          skillMatch: skillMatch
        }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to get answer');
      }
      
      const data = await response.json();
      setAnswer(data.answer);
      
      // Add to answered questions
      setAnsweredQuestions([
        ...answeredQuestions,
        { question: question, answer: data.answer }
      ]);
      
      // Clear form
      setQuestion('');
      setSelectedQuestion('');
    } catch (err) {
      setError('Failed to get answer. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!resumeAnalysis) {
    return (
      <Container size="sm" py="xl" className="text-center">
        <Stack spacing="md">
          <Title order={3}>No resume analysis available</Title>
          <Text c="dimmed">Please upload your resume first</Text>
          <Button onClick={() => setStep(1)}>
            Go to Upload Resume
          </Button>
        </Stack>
      </Container>
    );
  }

  if (!jobAnalysis) {
    return (
      <Container size="sm" py="xl" className="text-center">
        <Stack spacing="md">
          <Title order={3}>No job analysis available</Title>
          <Text c="dimmed">Please analyze a job posting first</Text>
          <Button onClick={() => setStep(2)}>
            Go to Job Analysis
          </Button>
        </Stack>
      </Container>
    );
  }

  // Interview tips based on job and resume analysis
  const interviewTips = [
    "Research the company thoroughly before your interview",
    "Prepare specific examples that demonstrate your skills and experience",
    "Practice answering common interview questions out loud",
    "Prepare thoughtful questions to ask the interviewer",
    "Connect your experience to the job requirements",
    "Be ready to discuss how you've overcome challenges",
    "Highlight your achievements with quantifiable results",
    "Show enthusiasm for the role and company",
    "Follow up with a thank-you note after the interview"
  ];

  return (
    <Container size="lg" py="xl">
      <Stack spacing="xl">
        <Box className="text-center">
          <Title order={1} className="text-blue-700 mb-2">Interview Preparation</Title>
          <Text size="lg" c="dimmed" className="max-w-2xl mx-auto">
            Practice answering interview questions tailored to this job
          </Text>
        </Box>

        {/* Ask Question Section */}
        <Card withBorder shadow="sm" radius="md">
          <Title order={3} mb="md">Ask an Interview Question</Title>
          
          <Stack spacing="md">
            {suggestedQuestions.length > 0 && (
              <Select
                label="Select a suggested question"
                placeholder="Choose from common questions for this role"
                data={suggestedQuestions.map(q => ({ value: q, label: q }))}
                value={selectedQuestion}
                onChange={handleSelectedQuestionChange}
                searchable
                clearable
                nothingFound="No questions found"
                icon={<IconSearch size={16} />}
              />
            )}
            
            <Text size="sm" fw={500}>Or type your own question:</Text>
            <Textarea
              placeholder="E.g., How would you handle a situation where..."
              value={question}
              onChange={handleQuestionChange}
              minRows={3}
              autosize
              maxRows={5}
            />
            
            <Group position="right">
              <Button 
                onClick={handleAskQuestion} 
                loading={loading}
                disabled={!question.trim() || loading}
              >
                Get Answer
              </Button>
            </Group>
            
            {error && (
              <Alert 
                icon={<IconAlertCircle size={16} />} 
                title="Error" 
                color="red" 
                variant="filled"
              >
                {error}
              </Alert>
            )}
            
            {loading && (
              <Box className="text-center" py="md">
                <Loader size="md" />
                <Text mt="sm" c="dimmed">
                  Generating your answer...
                </Text>
              </Box>
            )}
          </Stack>
          
          {answer && (
            <Paper withBorder p="md" mt="xl" radius="md">
              <Title order={4} mb="sm">Answer:</Title>
              <Text>{answer}</Text>
            </Paper>
          )}
        </Card>

        {/* Previously Answered Questions */}
        {answeredQuestions.length > 0 && (
          <Card withBorder shadow="sm" radius="md">
            <Title order={3} mb="md">Previously Answered Questions</Title>
            <Accordion>
              {answeredQuestions.map((qa, index) => (
                <Accordion.Item key={index} value={`question-${index}`}>
                  <Accordion.Control>
                    <Text fw={500}>{qa.question}</Text>
                  </Accordion.Control>
                  <Accordion.Panel>
                    <Text>{qa.answer}</Text>
                  </Accordion.Panel>
                </Accordion.Item>
              ))}
            </Accordion>
          </Card>
        )}

        {/* Interview Tips */}
        <Card withBorder shadow="sm" radius="md">
          <Title order={3} mb="md">
            <Group spacing="xs">
              <IconBulb size={24} />
              <span>Interview Tips</span>
            </Group>
          </Title>
          
          <List
            spacing="sm"
            icon={
              <ThemeIcon color="blue" size={24} radius="xl">
                <IconCheck size={16} />
              </ThemeIcon>
            }
          >
            {interviewTips.map((tip, index) => (
              <List.Item key={index}>{tip}</List.Item>
            ))}
          </List>
          
          <Divider my="lg" />
          
          <Text fw={500} mb="sm">Job-Specific Tips:</Text>
          <Text>
            For this {jobAnalysis.job_title} role at {jobAnalysis.company_name}, 
            be prepared to discuss your experience with {jobAnalysis.required_skills?.technical?.slice(0, 3).join(', ') || 'relevant technical skills'} 
            and how you've demonstrated {jobAnalysis.required_skills?.soft?.slice(0, 2).join(' and ') || 'key soft skills'} in previous roles.
          </Text>
        </Card>

        <Box className="text-center" mt="md">
          <Group position="center" spacing="md">
            <Button 
              variant="light"
              leftSection={<IconArrowLeft size={16} />}
              onClick={() => setStep(4)}
            >
              Back to Skill Match
            </Button>
            <Button 
              size="lg"
              rightSection={<IconArrowRight size={16} />}
              onClick={() => setStep(1)}
            >
              Start Over
            </Button>
          </Group>
        </Box>
      </Stack>
    </Container>
  );
};

export default InterviewQA; 