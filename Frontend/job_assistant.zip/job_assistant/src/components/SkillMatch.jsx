import React, { useEffect, useState } from 'react';
import {
  Container,
  Title,
  Text,
  Card,
  Badge,
  Progress,
  Group,
  Stack,
  Button,
  Alert,
  Loader,
  List,
  ThemeIcon,
  Paper,
  Box,
  Divider,
  rem,
  SimpleGrid,
} from '@mantine/core';
import {
  IconCheck,
  IconX,
  IconAlertCircle,
  IconArrowRight,
  IconArrowLeft,
  IconBulb,
  IconSchool,
  IconTrophy,
  IconBriefcase,
  IconPercentage,
  IconChartBar,
  IconListCheck,
  IconTools,
  IconHeartHandshake,
} from '@tabler/icons-react';
import { useJobContext } from '../context/JobContext';

const SkillMatch = () => {
  const {
    resumeAnalysis,
    jobAnalysis,
    skillMatch,
    matchSkills,
    setStep,
    isMatchingSkills,
  } = useJobContext();
  const [error, setError] = useState(null);

  const performSkillMatch = async () => {
    if (resumeAnalysis && jobAnalysis) {
      try {
        setError(null);
        await matchSkills();
      } catch (err) {
        setError('Failed to match skills. Please try again.');
        console.error('Error matching skills:', err);
      }
    }
  };

  useEffect(() => {
    if (resumeAnalysis && jobAnalysis && !skillMatch && !isMatchingSkills) {
      performSkillMatch();
    }
  }, [resumeAnalysis, jobAnalysis, skillMatch, isMatchingSkills]);

  if (!resumeAnalysis) {
    return (
      <Container size="lg" py="xl">
        <Alert 
          icon={<IconAlertCircle size={16} />} 
          title="Resume Analysis Required" 
          color="blue" 
          variant="filled"
          mb="md"
        >
          Please upload and analyze your resume first.
        </Alert>
        <Button 
          leftSection={<IconArrowLeft size={16} />} 
          onClick={() => setStep(1)}
          variant="light"
          color="blue"
        >
          Go to Resume Analysis
        </Button>
      </Container>
    );
  }

  if (!jobAnalysis) {
    return (
      <Container size="lg" py="xl">
        <Alert 
          icon={<IconAlertCircle size={16} />} 
          title="Job Analysis Required" 
          color="blue" 
          variant="filled"
          mb="md"
        >
          Please analyze a job posting first.
        </Alert>
        <Button 
          leftSection={<IconArrowLeft size={16} />} 
          onClick={() => setStep(2)}
          variant="light"
          color="blue"
        >
          Go to Job Analysis
        </Button>
      </Container>
    );
  }

  if (isMatchingSkills) {
    return (
      <Container size="lg" py="xl">
        <Card withBorder shadow="sm" radius="md" p="xl" className="text-center">
          <Loader size="md" className="mx-auto mb-4" />
          <Title order={3} mb="md">Analyzing Skill Match</Title>
          <Text>Comparing your resume with the job requirements...</Text>
        </Card>
      </Container>
    );
  }

  if (error) {
    return (
      <Container size="lg" py="xl">
        <Alert 
          icon={<IconAlertCircle size={16} />} 
          title="Error" 
          color="red" 
          variant="filled"
          mb="md"
        >
          {error}
        </Alert>
        <Button 
          onClick={performSkillMatch}
          variant="light"
          color="blue"
          mb="md"
        >
          Try Again
        </Button>
        <Button 
          leftSection={<IconArrowLeft size={16} />} 
          onClick={() => setStep(2)}
          variant="subtle"
        >
          Back to Job Analysis
        </Button>
      </Container>
    );
  }

  if (!skillMatch) {
    return (
      <Container size="lg" py="xl">
        <Card withBorder shadow="sm" radius="md" p="xl" className="text-center">
          <Loader size="md" className="mx-auto mb-4" />
          <Title order={3} mb="md">Preparing Skill Match</Title>
          <Text>Please wait while we analyze your skills...</Text>
        </Card>
      </Container>
    );
  }

  const {
    overall_match = {},
    technical_skills_match = {},
    soft_skills_match = {},
    experience_match = {},
    education_match = {},
    missing_skills = [],
    strengths = [],
    improvement_areas = [],
    match_summary = ''
  } = skillMatch;

  // Function to render match percentage
  const renderMatchPercentage = (match) => {
    if (!match || typeof match !== 'object') return null;
    
    // Check if match has percentage property
    const percentage = match.percentage ? 
      (typeof match.percentage === 'number' ? match.percentage : parseInt(match.percentage)) : 
      0;
    
    // Get color based on percentage
    let color = 'red';
    if (percentage >= 80) color = 'green';
    else if (percentage >= 60) color = 'blue';
    else if (percentage >= 40) color = 'yellow';
    
    return (
      <Box>
        <Group position="apart" mb={5}>
          <Text fw={500}>{percentage}% Match</Text>
          <Badge color={color}>{percentage >= 70 ? 'Strong' : percentage >= 50 ? 'Moderate' : 'Needs Improvement'}</Badge>
        </Group>
        <Progress value={percentage} color={color} size="md" radius="xs" />
        {match.assessment && typeof match.assessment === 'string' && (
          <Text mt="xs" size="sm">{match.assessment}</Text>
        )}
        {match.recommendation && typeof match.recommendation === 'string' && (
          <Text mt="xs" size="sm" c="dimmed">
            <strong>Recommendation:</strong> {match.recommendation}
          </Text>
        )}
      </Box>
    );
  };

  return (
    <Container size="lg" py="xl">
      <Stack spacing="xl">
        <Box className="text-center">
          <Title order={1} className="text-blue-700 mb-2">Skill Match Analysis</Title>
          <Text size="lg" c="dimmed" className="max-w-2xl mx-auto">
            How your skills and experience match with the job requirements
          </Text>
        </Box>

        {/* Overall Match */}
        <Card withBorder shadow="sm" radius="md" p="lg" className="bg-blue-50/30">
          <Title order={3} mb="lg" className="text-blue-800">Overall Match</Title>
          {renderMatchPercentage(overall_match)}
          
          {match_summary && typeof match_summary === 'string' && (
            <Paper withBorder p="md" radius="md" mt="md" className="bg-white">
              <Text>{match_summary}</Text>
            </Paper>
          )}
        </Card>

        {/* Match Categories */}
        <SimpleGrid cols={2} spacing="md" breakpoints={[{ maxWidth: 'sm', cols: 1 }]}>
          {/* Technical Skills */}
          <Card withBorder shadow="sm" radius="md" p="md">
            <Group mb="md">
              <ThemeIcon size={32} radius="md" color="blue">
                <IconTools size={18} />
              </ThemeIcon>
              <Title order={4}>Technical Skills</Title>
            </Group>
            {renderMatchPercentage(technical_skills_match)}
          </Card>
          
          {/* Soft Skills */}
          <Card withBorder shadow="sm" radius="md" p="md">
            <Group mb="md">
              <ThemeIcon size={32} radius="md" color="green">
                <IconHeartHandshake size={18} />
              </ThemeIcon>
              <Title order={4}>Soft Skills</Title>
            </Group>
            {renderMatchPercentage(soft_skills_match)}
          </Card>
          
          {/* Experience */}
          <Card withBorder shadow="sm" radius="md" p="md">
            <Group mb="md">
              <ThemeIcon size={32} radius="md" color="indigo">
                <IconBriefcase size={18} />
              </ThemeIcon>
              <Title order={4}>Experience</Title>
            </Group>
            {renderMatchPercentage(experience_match)}
          </Card>
          
          {/* Education */}
          <Card withBorder shadow="sm" radius="md" p="md">
            <Group mb="md">
              <ThemeIcon size={32} radius="md" color="violet">
                <IconSchool size={18} />
              </ThemeIcon>
              <Title order={4}>Education</Title>
            </Group>
            {renderMatchPercentage(education_match)}
          </Card>
        </SimpleGrid>

        {/* Strengths */}
        {strengths && strengths.length > 0 && (
          <Card withBorder shadow="sm" radius="md" p="lg" className="bg-green-50/30">
            <Title order={4} mb="md" className="text-green-800">Your Strengths</Title>
            <List
              spacing="sm"
              icon={
                <ThemeIcon color="green" size={24} radius="xl">
                  <IconCheck size={16} />
                </ThemeIcon>
              }
            >
              {strengths.map((strength, index) => (
                <List.Item key={index}>
                  {typeof strength === 'string' ? strength : 
                   (strength.description ? strength.description : JSON.stringify(strength))}
                </List.Item>
              ))}
            </List>
          </Card>
        )}

        {/* Missing Skills */}
        {missing_skills && missing_skills.length > 0 && (
          <Card withBorder shadow="sm" radius="md" p="lg" className="bg-amber-50/30">
            <Title order={4} mb="md" className="text-amber-800">Skills to Develop</Title>
            <List
              spacing="sm"
              icon={
                <ThemeIcon color="yellow" size={24} radius="xl">
                  <IconBulb size={16} />
                </ThemeIcon>
              }
            >
              {missing_skills.map((skill, index) => (
                <List.Item key={index}>
                  {typeof skill === 'string' ? skill : 
                   (skill.name ? skill.name : JSON.stringify(skill))}
                  {skill.importance && typeof skill.importance === 'string' && (
                    <Badge ml="xs" color="yellow" variant="light">
                      {skill.importance}
                    </Badge>
                  )}
                  {skill.suggestion && typeof skill.suggestion === 'string' && (
                    <Text size="sm" c="dimmed" mt={4}>
                      Suggestion: {skill.suggestion}
                    </Text>
                  )}
                </List.Item>
              ))}
            </List>
          </Card>
        )}

        {/* Improvement Areas */}
        {improvement_areas && improvement_areas.length > 0 && (
          <Card withBorder shadow="sm" radius="md" p="lg" className="bg-blue-50/30">
            <Title order={4} mb="md" className="text-blue-800">Areas for Improvement</Title>
            <List
              spacing="md"
              icon={
                <ThemeIcon color="blue" size={24} radius="xl">
                  <IconArrowRight size={16} />
                </ThemeIcon>
              }
            >
              {improvement_areas.map((area, index) => (
                <List.Item key={index}>
                  {typeof area === 'string' ? area : 
                   (area.area ? area.area : JSON.stringify(area))}
                  {area.suggestion && typeof area.suggestion === 'string' && (
                    <Text size="sm" mt={4}>
                      {area.suggestion}
                    </Text>
                  )}
                </List.Item>
              ))}
            </List>
          </Card>
        )}

        <Box className="text-center" mt="md">
          <Button 
            size="lg"
            rightSection={<IconArrowRight size={16} />}
            onClick={() => setStep(4)}
            color="blue"
          >
            Continue to Interview Prep
          </Button>
        </Box>
      </Stack>
    </Container>
  );
};

export default SkillMatch; 