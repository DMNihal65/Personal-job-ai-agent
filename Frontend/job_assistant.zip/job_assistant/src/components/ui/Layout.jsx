import { useState, useEffect } from 'react';
import { 
  AppShell, 
  Burger, 
  Group, 
  NavLink, 
  Title, 
  Text, 
  Button, 
  Progress, 
  Badge, 
  Drawer, 
  Stack, 
  Alert, 
  LoadingOverlay, 
  Box, 
  Container,
  
} from '@mantine/core';
import { 
  IconFileText, 
  IconBriefcase, 
  IconChartPie, 
  IconMessageCircle, 
  IconHome, 
  IconX, 
  IconAlertCircle 
} from '@tabler/icons-react';
import { useJobContext } from '../../context/JobContext';

const Layout = ({ children }) => {
  const { 
    step, 
    setStep, 
    loading, 
    error,
    resumeAnalysis,
    jobAnalysis,
    skillMatch,
    resetApplication
  } = useJobContext();

  const [drawerOpened, setDrawerOpened] = useState(false);
  const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 0);

  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Menu items based on completed steps
  const menuItems = [
    {
      key: '1',
      icon: <IconHome size={18} stroke={1.5} />,
      label: 'Home',
      disabled: false,
      completed: true,
    },
    {
      key: '2',
      icon: <IconFileText size={18} stroke={1.5} />,
      label: 'Resume Analysis',
      disabled: !resumeAnalysis,
      completed: !!resumeAnalysis,
    },
    {
      key: '3',
      icon: <IconBriefcase size={18} stroke={1.5} />,
      label: 'Job Analysis',
      disabled: !jobAnalysis,
      completed: !!jobAnalysis,
    },
    {
      key: '4',
      icon: <IconChartPie size={18} stroke={1.5} />,
      label: 'Skill Match',
      disabled: !skillMatch,
      completed: !!skillMatch,
    },
    {
      key: '5',
      icon: <IconMessageCircle size={18} stroke={1.5} />,
      label: 'Interview Q&A',
      disabled: !skillMatch,
      completed: step >= 5,
    },
  ];

  // Handle menu item click
  const handleMenuClick = (key) => {
    const numKey = parseInt(key, 10);
    if (key === '1') {
      setStep(1);
    } else if (key === '2' && resumeAnalysis) {
      setStep(2);
    } else if (key === '3' && jobAnalysis) {
      setStep(3);
    } else if (key === '4' && skillMatch) {
      setStep(4);
    } else if (key === '5' && skillMatch) {
      setStep(5);
    }
    
    // Close drawer on mobile after selection
    if (windowWidth < 768) {
      setDrawerOpened(false);
    }
  };

  // Progress indicator
  const getProgressPercent = () => {
    if (skillMatch && step >= 5) return 100;
    if (skillMatch) return 80;
    if (jobAnalysis) return 60;
    if (resumeAnalysis) return 40;
    return 20;
  };

  const progressPercent = getProgressPercent();

  return (
    <AppShell
      header={{ height: 60 }}
      navbar={{ 
        width: 250, 
        breakpoint: 'sm', 
        collapsed: { mobile: true, desktop: false } 
      }}
      padding="md"
      className="bg-gray-50"
    >
      <AppShell.Header className="bg-white border-b border-gray-200">
        <Group justify="space-between" h="100%" px="md">
          <Group>
            {windowWidth < 768 && (
              <Burger
                opened={drawerOpened}
                onClick={() => setDrawerOpened(!drawerOpened)}
                size="sm"
                color="gray"
              />
            )}
            <Group>
              <div className="bg-blue-600 w-8 h-8 rounded-lg flex items-center justify-center">
                <IconFileText size={18} className="text-white" stroke={1.5} />
              </div>
              <Title order={4} className="text-blue-600 hidden sm:block m-0">Job Application Assistant</Title>
              <Title order={4} className="text-blue-600 sm:hidden m-0">Job Assistant</Title>
            </Group>
          </Group>
          
          <Group>
            <div className="hidden md:block mr-4">
              <Group>
                <Progress 
                  value={progressPercent} 
                  size="sm" 
                  w={120} 
                  color="blue" 
                  radius="xl"
                />
                <Text size="sm" c="dimmed">{progressPercent}%</Text>
              </Group>
            </div>
            <Button 
              variant="outline" 
              color="red" 
              onClick={resetApplication}
              leftSection={<IconX size={16} />}
              size="sm"
            >
              Reset
            </Button>
          </Group>
        </Group>
      </AppShell.Header>

      {windowWidth >= 768 ? (
        <AppShell.Navbar p="md" className="bg-white border-r border-gray-200">
          <Box mb="md" pb="md" className="border-b border-gray-200">
            <Text size="sm" fw={500} mb={4}>Progress</Text>
            <Progress 
              value={progressPercent} 
              size="sm" 
              mb={8} 
              color="blue" 
              radius="xl"
            />
            <Group justify="space-between">
              <Text size="xs" c="dimmed">Completion</Text>
              <Text size="xs" fw={500}>{progressPercent}%</Text>
            </Group>
          </Box>
          
          <Stack gap="xs">
            {menuItems.map((item) => (
              <NavLink
                key={item.key}
                label={item.label}
                leftSection={item.icon}
                active={step.toString() === item.key}
                disabled={item.disabled}
                onClick={() => handleMenuClick(item.key)}
                rightSection={
                  item.completed ? (
                    <Badge size="xs" variant="filled" color="green" radius="xl" p={0} w={8} h={8} />
                  ) : null
                }
              />
            ))}
          </Stack>
        </AppShell.Navbar>
      ) : (
        <Drawer
          opened={drawerOpened}
          onClose={() => setDrawerOpened(false)}
          title="Navigation"
          size="xs"
          overlayProps={{ backgroundOpacity: 0.5, blur: 4 }}
        >
          <Box mb="md" pb="md" className="border-b border-gray-200">
            <Text size="sm" fw={500} mb={4}>Progress</Text>
            <Progress 
              value={progressPercent} 
              size="sm" 
              mb={8} 
              color="blue" 
              radius="xl"
            />
            <Group justify="space-between">
              <Text size="xs" c="dimmed">Completion</Text>
              <Text size="xs" fw={500}>{progressPercent}%</Text>
            </Group>
          </Box>
          
          <Stack gap="xs">
            {menuItems.map((item) => (
              <NavLink
                key={item.key}
                label={item.label}
                leftSection={item.icon}
                active={step.toString() === item.key}
                disabled={item.disabled}
                onClick={() => handleMenuClick(item.key)}
                rightSection={
                  item.completed ? (
                    <Badge size="xs" variant="filled" color="green" radius="xl" p={0} w={8} h={8} />
                  ) : null
                }
              />
            ))}
          </Stack>
        </Drawer>
      )}

      <AppShell.Main>
        <Container size="lg" py="md">
          {error && (
            <Alert 
              color="red" 
              title="Error" 
              icon={<IconAlertCircle size={16} />}
              mb="md"
              withCloseButton
            >
              {error}
            </Alert>
          )}
          
          <Box pos="relative" className="bg-white p-6 rounded-lg shadow-sm min-h-[calc(100vh-160px)]">
            <LoadingOverlay 
              visible={loading} 
              overlayBlur={2}
              loaderProps={{ size: 'lg', color: 'blue' }}
            />
            {children}
          </Box>
        </Container>
      </AppShell.Main>
      
      <AppShell.Footer height={50} className="bg-white border-t border-gray-200">
        <Group justify="center" h="100%">
          <Text size="sm" c="dimmed">
            Job Application Assistant © {new Date().getFullYear()} Created with ❤️
          </Text>
        </Group>
      </AppShell.Footer>
    </AppShell>
  );
};

export default Layout; 