import { useEffect } from 'react';
import { JobProvider, useJobContext } from './context/JobContext';
import { AppShell } from '@mantine/core';
import { Notifications } from '@mantine/notifications';
import Layout from './components/ui/Layout';
import Home from './components/Home';
import ResumeAnalysis from './components/ResumeAnalysis';
import JobAnalysis from './components/JobAnalysis';
import SkillMatch from './components/SkillMatch';
import InterviewQA from './components/InterviewQA';

const MainContent = () => {
  const { step } = useJobContext();

  // useEffect(() => {
  //   // Check API health when component mounts
  //   checkHealth();
  // }, [checkHealth]);

  // Render the appropriate component based on the current step
  const renderContent = () => {
    switch (step) {
      case 1:
        return <Home />;
      case 2:
        return <ResumeAnalysis />;
      case 3:
        return <JobAnalysis />;
      case 4:
        return <SkillMatch />;
      case 5:
        return <InterviewQA />;
      default:
        return <Home />;
    }
  };

  return (
    <Layout>
      {renderContent()}
    </Layout>
  );
};

function App() {
  return (
    <>
      <Notifications position="top-right" zIndex={1000} />
      <JobProvider>
        <AppShell>
          <MainContent />
        </AppShell>
      </JobProvider>
    </>
  );
}

export default App;
