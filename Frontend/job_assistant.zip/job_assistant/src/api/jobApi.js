import axios from 'axios';

// Base URL for the API
const API_BASE_URL = 'http://localhost:8000';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// API functions
export const jobApi = {
  // Health check
  checkHealth: async () => {
    try {
      const response = await api.get('/');
      return response.data;
    } catch (error) {
      console.error('API Health Check Error:', error);
      throw error;
    }
  },

  // Resume processing
  uploadResume: async (resumeFile, sessionId = null) => {
    try {
      const formData = new FormData();
      formData.append('resume_file', resumeFile);
      if (sessionId) {
        formData.append('session_id', sessionId);
      }

      const response = await axios.post(`${API_BASE_URL}/resume`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response.data;
    } catch (error) {
      console.error('Resume Upload Error:', error);
      throw error;
    }
  },

  getResumeAnalysis: async (sessionId) => {
    try {
      const response = await api.get(`/resume/${sessionId}`);
      return response.data;
    } catch (error) {
      console.error('Get Resume Analysis Error:', error);
      throw error;
    }
  },

  // Job processing
  processJobUrl: async (jobUrl, sessionId) => {
    try {
      const response = await api.post('/job', {
        url: jobUrl,
        session_id: sessionId,
      });
      return response.data;
    } catch (error) {
      console.error('Process Job URL Error:', error);
      throw error;
    }
  },

  getJobAnalysis: async (sessionId) => {
    try {
      const response = await api.get(`/job/${sessionId}`);
      return response.data;
    } catch (error) {
      console.error('Get Job Analysis Error:', error);
      throw error;
    }
  },

  // Skill matching
  matchSkills: async (sessionId) => {
    try {
      const response = await api.post('/match', {
        session_id: sessionId,
      });
      return response.data;
    } catch (error) {
      console.error('Match Skills Error:', error);
      throw error;
    }
  },

  getSkillMatch: async (sessionId) => {
    try {
      const response = await api.get(`/match/${sessionId}`);
      return response.data;
    } catch (error) {
      console.error('Get Skill Match Error:', error);
      throw error;
    }
  },

  // Question answering
  answerQuestion: async (sessionId, question) => {
    try {
      const response = await api.post('/question', {
        session_id: sessionId,
        question,
      });
      return response.data;
    } catch (error) {
      console.error('Answer Question Error:', error);
      throw error;
    }
  },

  getSuggestedQuestions: async (sessionId) => {
    try {
      const response = await api.get(`/questions/${sessionId}`);
      return response.data;
    } catch (error) {
      console.error('Get Suggested Questions Error:', error);
      throw error;
    }
  },

  // Session management
  deleteSession: async (sessionId) => {
    try {
      const response = await api.delete(`/session/${sessionId}`);
      return response.data;
    } catch (error) {
      console.error('Delete Session Error:', error);
      throw error;
    }
  },

  // Helper function to poll for results
  pollForResults: async (sessionId, endpoint, maxAttempts = 20, interval = 3000) => {
    let attempts = 0;
    
    const poll = async () => {
      try {
        attempts++;
        const response = await api.get(`/${endpoint}/${sessionId}`);
        
        // If status is 202, it's still processing
        if (response.status === 202) {
          if (attempts >= maxAttempts) {
            throw new Error('Polling timeout: Maximum attempts reached');
          }
          
          // Wait and try again
          await new Promise(resolve => setTimeout(resolve, interval));
          return poll();
        }
        
        return response.data;
      } catch (error) {
        if (error.response && error.response.status === 202) {
          if (attempts >= maxAttempts) {
            throw new Error('Polling timeout: Maximum attempts reached');
          }
          
          // Wait and try again
          await new Promise(resolve => setTimeout(resolve, interval));
          return poll();
        }
        
        throw error;
      }
    };
    
    return poll();
  }
};

export default jobApi; 