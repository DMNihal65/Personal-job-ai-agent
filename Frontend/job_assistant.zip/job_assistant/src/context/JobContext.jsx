import { createContext, useContext, useState, useEffect } from 'react';
import jobApi from '../api/jobApi';

// Create context
const JobContext = createContext();

// Custom hook to use the context
export const useJobContext = () => useContext(JobContext);

// Context provider component
export const JobProvider = ({ children }) => {
  // State variables
  const [sessionId, setSessionId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [step, setStep] = useState(1); // 1: Home, 2: Resume Analysis, 3: Job Analysis, 4: Skill Match, 5: Interview Q&A
  
  const [resumeFile, setResumeFile] = useState(null);
  const [resumeAnalysis, setResumeAnalysis] = useState(null);
  const [resumeProcessing, setResumeProcessing] = useState(false);
  
  const [jobUrl, setJobUrl] = useState('');
  const [jobAnalysis, setJobAnalysis] = useState(null);
  const [jobProcessing, setJobProcessing] = useState(false);
  
  const [skillMatch, setSkillMatch] = useState(null);
  const [skillMatchProcessing, setSkillMatchProcessing] = useState(false);
  
  const [suggestedQuestions, setSuggestedQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [questionAnswer, setQuestionAnswer] = useState('');
  const [questionProcessing, setQuestionProcessing] = useState(false);
  
  // Check if session exists in localStorage on mount
  useEffect(() => {
    const savedSessionId = localStorage.getItem('jobAssistantSessionId');
    if (savedSessionId) {
      setSessionId(savedSessionId);
      
      // Check if we have saved data for this session
      const savedStep = localStorage.getItem('jobAssistantStep');
      if (savedStep) {
        setStep(parseInt(savedStep, 10));
      }
      
      // Load saved data if available
      const savedResumeAnalysis = localStorage.getItem('jobAssistantResumeAnalysis');
      if (savedResumeAnalysis) {
        setResumeAnalysis(JSON.parse(savedResumeAnalysis));
      }
      
      const savedJobAnalysis = localStorage.getItem('jobAssistantJobAnalysis');
      if (savedJobAnalysis) {
        setJobAnalysis(JSON.parse(savedJobAnalysis));
      }
      
      const savedSkillMatch = localStorage.getItem('jobAssistantSkillMatch');
      if (savedSkillMatch) {
        setSkillMatch(JSON.parse(savedSkillMatch));
      }
      
      const savedSuggestedQuestions = localStorage.getItem('jobAssistantSuggestedQuestions');
      if (savedSuggestedQuestions) {
        setSuggestedQuestions(JSON.parse(savedSuggestedQuestions));
      }
    }
  }, []);
  
  // Save session data to localStorage when it changes
  useEffect(() => {
    if (sessionId) {
      localStorage.setItem('jobAssistantSessionId', sessionId);
    }
  }, [sessionId]);
  
  useEffect(() => {
    if (step) {
      localStorage.setItem('jobAssistantStep', step);
    }
  }, [step]);
  
  useEffect(() => {
    if (resumeAnalysis) {
      localStorage.setItem('jobAssistantResumeAnalysis', JSON.stringify(resumeAnalysis));
    }
  }, [resumeAnalysis]);
  
  useEffect(() => {
    if (jobAnalysis) {
      localStorage.setItem('jobAssistantJobAnalysis', JSON.stringify(jobAnalysis));
    }
  }, [jobAnalysis]);
  
  useEffect(() => {
    if (skillMatch) {
      localStorage.setItem('jobAssistantSkillMatch', JSON.stringify(skillMatch));
    }
  }, [skillMatch]);
  
  useEffect(() => {
    if (suggestedQuestions.length > 0) {
      localStorage.setItem('jobAssistantSuggestedQuestions', JSON.stringify(suggestedQuestions));
    }
  }, [suggestedQuestions]);
  
  // Function to handle resume upload
  const handleResumeUpload = async (file) => {
    try {
      setLoading(true);
      setError(null);
      setResumeFile(file);
      setResumeProcessing(true);
      
      // Upload resume
      const response = await jobApi.uploadResume(file, sessionId);
      
      // Save session ID if not already set
      if (!sessionId) {
        setSessionId(response.session_id);
      }
      
      // Poll for resume analysis results
      const analysis = await jobApi.pollForResults(response.session_id, 'resume');
      
      setResumeAnalysis(analysis);
      setResumeProcessing(false);
      setStep(2); // Move to next step
    } catch (err) {
      setError(err.message || 'Error uploading resume');
      setResumeProcessing(false);
    } finally {
      setLoading(false);
    }
  };
  
  // Function to handle job URL processing
  const handleJobUrlSubmit = async (url) => {
    try {
      setLoading(true);
      setError(null);
      setJobUrl(url);
      setJobProcessing(true);
      
      // Process job URL
      const response = await jobApi.processJobUrl(url, sessionId);
      
      // Poll for job analysis results
      const analysis = await jobApi.pollForResults(sessionId, 'job');
      
      setJobAnalysis(analysis);
      setJobProcessing(false);
      setStep(3); // Move to next step
      
      // Automatically start skill matching
      await handleSkillMatch();
    } catch (err) {
      setError(err.message || 'Error processing job URL');
      setJobProcessing(false);
    } finally {
      setLoading(false);
    }
  };
  
  // Function to handle skill matching
  const handleSkillMatch = async () => {
    try {
      setLoading(true);
      setError(null);
      setSkillMatchProcessing(true);
      
      // Request skill matching
      await jobApi.matchSkills(sessionId);
      
      // Poll for skill match results
      const match = await jobApi.pollForResults(sessionId, 'match');
      
      setSkillMatch(match);
      setSkillMatchProcessing(false);
      
      // Get suggested questions
      const questions = await jobApi.getSuggestedQuestions(sessionId);
      setSuggestedQuestions(questions.questions || []);
      
      setStep(4); // Move to next step
    } catch (err) {
      setError(err.message || 'Error matching skills');
      setSkillMatchProcessing(false);
    } finally {
      setLoading(false);
    }
  };
  
  // Function to handle question answering
  const handleQuestionSubmit = async (question) => {
    try {
      setLoading(true);
      setError(null);
      setCurrentQuestion(question);
      setQuestionProcessing(true);
      
      // Get answer to question
      const response = await jobApi.answerQuestion(sessionId, question);
      
      setQuestionAnswer(response.answer);
      setQuestionProcessing(false);
    } catch (err) {
      setError(err.message || 'Error answering question');
      setQuestionProcessing(false);
    } finally {
      setLoading(false);
    }
  };
  
  // Function to reset the application
  const resetApplication = async () => {
    try {
      setLoading(true);
      
      // Delete session if it exists
      if (sessionId) {
        await jobApi.deleteSession(sessionId);
      }
      
      // Clear all state
      setSessionId(null);
      setStep(1);
      setResumeFile(null);
      setResumeAnalysis(null);
      setJobUrl('');
      setJobAnalysis(null);
      setSkillMatch(null);
      setSuggestedQuestions([]);
      setCurrentQuestion('');
      setQuestionAnswer('');
      
      // Clear localStorage
      localStorage.removeItem('jobAssistantSessionId');
      localStorage.removeItem('jobAssistantStep');
      localStorage.removeItem('jobAssistantResumeAnalysis');
      localStorage.removeItem('jobAssistantJobAnalysis');
      localStorage.removeItem('jobAssistantSkillMatch');
      localStorage.removeItem('jobAssistantSuggestedQuestions');
    } catch (err) {
      setError(err.message || 'Error resetting application');
    } finally {
      setLoading(false);
    }
  };
  
  // Context value
  const contextValue = {
    sessionId,
    loading,
    error,
    step,
    setStep,
    
    resumeFile,
    resumeAnalysis,
    resumeProcessing,
    handleResumeUpload,
    
    jobUrl,
    jobAnalysis,
    jobProcessing,
    handleJobUrlSubmit,
    
    skillMatch,
    skillMatchProcessing,
    handleSkillMatch,
    
    suggestedQuestions,
    currentQuestion,
    questionAnswer,
    questionProcessing,
    handleQuestionSubmit,
    
    resetApplication,
  };
  
  return (
    <JobContext.Provider value={contextValue}>
      {children}
    </JobContext.Provider>
  );
};

export default JobContext; 